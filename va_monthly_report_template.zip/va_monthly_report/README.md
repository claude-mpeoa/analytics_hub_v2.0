# Virgin Active Monthly Marketing Performance Report

Open `index.html` through a web server. The report reads CSV files from the `data` folder.

## Recommended local preview

From this folder run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

Do not open `index.html` directly with `file://` because many browsers block JavaScript from reading local CSV files.

## CSV files used

- `data/report_config.csv`
- `data/daily_performance.csv`
- `data/channel_performance.csv`
- `data/branch_performance.csv`
- `data/narrative_inputs.csv`

## RAG formulas

- Sales vs target: green >= 100%, amber >= 95%, red < 95%.
- ROI: green >= 10x, amber >= 5x, red < 5x. Zero-spend channels are neutral.
- Cost: green <= benchmark, amber <= 10% above benchmark, red > 10% above benchmark.
- Contact rate: green >= 80%, amber >= 70%, red < 70%.
